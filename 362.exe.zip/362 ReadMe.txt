 _______  ___      _______        _______  __   __  _______ 
|       ||   |    |       |      |       ||  |_|  ||       |
|___    ||   |___ |____   |      |    ___||       ||    ___|
 ___|   ||    _  | ____|  |      |   |___ |       ||   |___ 
|___    ||   | | || ______| ___  |    ___| |     | |    ___|
 ___|   ||   |_| || |_____ |   | |   |___ |   _   ||   |___ 
|_______||_______||_______||___| |_______||__| |__||_______|
Finally finished this malware.
Created in C++
Payloads: 4
This malware can delete registry and disable task manager, I'm not responsible for any damage!!!
Run only in vm.
